// vite.config.js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { createJestConfig } from 'vite-plugin-jest'

export default defineConfig({
  plugins: [
    react(),
    createJestConfig()  // Nur notwendig, wenn Sie `vite-plugin-jest` verwenden
  ],
})
