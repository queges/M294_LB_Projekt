module.exports = {
  presets: [
    '@babel/preset-env', // für ES6+ Syntax
    '@babel/preset-react' // für JSX Syntax
  ],
};
